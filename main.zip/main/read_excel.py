import os, sys
import win32com.client
from win32com.client import Dispatch

class Read_Excel():

    def __init__(self, filename, sheetname):
        # open file
        self.filename=filename
        self.sheetname=sheetname
        self.xl=win32com.client.gencache.EnsureDispatch("Excel.Application")
        self.xl.Visible=False

        try:
            self.wb=self.xl.Workbooks.Open(self.filename)
        except:
            print ("Failed to open spreadsheet " + self.filename)
            return
    
        # get data
        try:
            self.data = self.wb.Sheets(self.sheetname).UsedRange.Value
        except:
            print('there is no sheet name as: '+ self.sheetname)
            return
       
        self.wb.Close(SaveChanges=False)
        #self.wb.Save()
        self.xl.Application.Quit() 